const greeting = "Welcome to my personal website!";
function firstHello() {
    alert(greeting);
}
firstHello();