# Personal-Website

Open main file: index.html. The about, portfolio, and javascript are linked. The javascript code creates an alert that pops up on only the home (index) page, though I was unfortunately not able to get it to only show up once - so it may pop up every time you open the home page. 